export const CARS = [
    {
        id: 1,
        brand: 'Tesla',
        color: 'white',
        model: 'Tesla S',
    },
];